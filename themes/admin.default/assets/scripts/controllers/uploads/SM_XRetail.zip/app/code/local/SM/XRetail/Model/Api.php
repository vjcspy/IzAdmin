<?php
class SM_XRetail_Model_Api extends Mage_Api_Model_Resource_Abstract
{        
		public function testCustomer()
        {
        }
}